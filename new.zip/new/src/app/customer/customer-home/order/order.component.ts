import { Component, OnInit } from '@angular/core';
import { OrderserviceService } from './orderservice.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  viewOrderDetails!:boolean;
  orderList!:any[];
  loggedInCustomer!:any;
  selectedOrderProduct:any;
  constructor(private orderService:OrderserviceService) { }

  ngOnInit() {
    // this.loggedCustomer = sessionStorage.getItem('Customer')
    this.loggedInCustomer = JSON.parse(sessionStorage.getItem("customer"));
    this.orderService.getOrders(this.loggedInCustomer.emailId).subscribe(
      order =>{
        console.log(order);
       this.orderList = order;
       if(this.orderList.length > 0){
         this.viewOrderDetails=true;
       }if(this.orderList.length === 0){
        this.viewOrderDetails = false;
       }
      }
    )

    if(this.orderList.length > 0){
      this.viewOrderDetails = true;
    }
  }

  setSelectedCart(){

  }

  deleteProductFromCart(){

  }

}
