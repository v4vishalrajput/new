import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-wishlist-product',
  templateUrl: './view-wishlist-product.component.html',
  styleUrls: ['./view-wishlist-product.component.css']
})
export class ViewWishlistProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
