import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { WishList } from 'src/app/shared/models/wishlist';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class WishlistService {
  private headers = new HttpHeaders({ 'Content-Type': 'text/plain' });
  constructor(private http: HttpClient) { }

  deleteProductFromWishList(wishlist: WishList, customerEmailId: string): Observable<string> {
      let url: string = environment.customerWishListUrl + "/deleteProductFromWishlist/" + customerEmailId;
      return this.http.post<string>(url, wishlist.wishListId, { headers: this.headers, responseType: 'text' as 'json' })
          .pipe(
              catchError(this.handleError)
          );

  }

  private handleError(err: HttpErrorResponse) {
      console.log(err)
      let errMsg: string = '';
      if (err.error instanceof Error) {
          errMsg = err.error.message;
          console.log(errMsg)
      }
      else if (typeof err.error === 'string') {
          errMsg = JSON.parse(err.error).message
      }
      else {
          if (err.status == 0) {
              errMsg = "A connection to back end can not be established.";
          } else {
              errMsg = err.error.message;
          }
      }
      return throwError(errMsg);
  }

  getCustomerWishList(emailId: any) {
      let url: string = environment.customerWishListUrl + "/getCustomerWishlist/" + emailId + '/';
      return this.http.get<WishList[]>(url)
          .pipe(catchError(this.handleError));
  }

}