import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Card } from './Card';
import { Location } from '@angular/common';
import { Customer } from 'src/app/shared/models/customer';

@Component({
  selector: 'app-add-card',
  templateUrl: './add-card.component.html',
  styleUrls: ['./add-card.component.css']
})
export class AddCardComponent implements OnInit {

  cardForm!: FormGroup;
  card!: Card;
  loggedInCustomer: Customer;

  constructor(private formBuilder: FormBuilder, private http: HttpClient, private location: Location) { }

  ngOnInit(): void {
    this.loggedInCustomer = JSON.parse(sessionStorage.getItem("customer"));
    this.cardForm = this.formBuilder.group({
      cardNumber: [''],
      expiryDate: [''],
      name: [''],
    });
  }

  onSubmit() {
    this.card = {
      cardNumber: this.cardForm.value.cardNumber,
      expiryDate: this.cardForm.value.expiryDate,
      name: this.cardForm.value.name,
      customerEmail: this.loggedInCustomer.emailId
    };
  }

  addCard() {
    this.http
      .post<any>('http://localhost:9111/cardInfo/add', this.card, {
        observe: 'response',
      })
      .subscribe((result) => {
        console.log('result', result);
        if (result.status == 200) {
          this.location.back();
        }
      });
  }

}
