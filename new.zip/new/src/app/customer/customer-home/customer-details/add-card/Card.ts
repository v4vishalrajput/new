export class Card {
    cardNumber!: number;
    expiryDate!:string;
    name!: string;
    customerEmail!:string;
}